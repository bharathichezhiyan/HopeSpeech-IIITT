# Hope-Speech-Detection-
Hope Speech Detection for Equality, Diversity, and Inclusion-EACL 2021
